%% generate_raw_inventory.m
%
% Walks a SHARC buoy's raw data tree (raw/ED, raw/GD, raw/WD, each split
% into session folders ES#/GS#/WS# containing individual .txt readings,
% and sometimes a pre-built "*All.csv") and produces one manifest table
% summarising every session: how many files, total size, and the
% time-of-day range covered.
%
% WHY: none of the raw session files carry a date, only HH:MM:SS. Before
% you can trust any date-reconstruction logic, you need to see the shape
% of the dataset — file counts per session, whether the time-of-day wraps
% past midnight within a session, and whether the sessions that already
% have an "*All.csv" behave the way you expect.
%
% USAGE:
%   Edit ROOT_DIR and BUOYS below, then run the script. It writes one CSV
%   per buoy (e.g. SB04_raw_inventory.csv) to OUTPUT_DIR, plus a combined
%   .mat file with the same tables for further MATLAB analysis.
%
% ASSUMPTIONS (confirm these against what your supervisor tells you):
%   - Each buoy folder contains a "raw" subfolder with ED, GD, WD inside.
%   - Session folders are named like ES1, GS3, WS27 (prefix + number).
%   - Each session folder holds individual "<Letter><number>.txt" files,
%     one line per WD file for reading? no — WD files may have multiple
%     lines (multiple samples per burst); ED/GD files are typically one
%     line. The script handles both by reading first and last line only.
%   - A file matching "*All.csv" (case-insensitive) inside a session
%     folder is a pre-built concatenation, not an individual reading.

clear; clc;

%% ---- Configuration ----------------------------------------------------
ROOT_DIR   = "C:\Users\Sandakahle\FYP\RAW";   % <-- EDIT: full path to the RAW folder containing SB01, SB04, ...
BUOYS      = ["SB04", "SB06"];             % <-- EDIT: buoys to inventory
OUTPUT_DIR = "/path/to/output";            % <-- EDIT: where to write manifests

% NOTE: ROOT_DIR must be a full path MATLAB can actually resolve.
%   - Windows example: "C:\Users\<you>\Documents\FYP\RAW"
%   - Mac/Linux example: "/Users/<you>/FYP/RAW"
%   - Or, if this script lives inside your FYP folder and RAW is a
%     sibling/child of it, build it relative to the script instead:
%       ROOT_DIR = fullfile(pwd, "RAW");
% A ROOT_DIR starting with "/" or "\" on Windows resolves to the root of
% the current drive, not a folder inside your project — that's what
% produced "\RAW\SB04\raw not found" earlier.

allManifests = struct();  % populated per buoy below; guards the final save()

STREAMS = struct( ...
    "code",   {"ED",  "GD",  "WD"}, ...
    "label",  {"Environmental", "GPS", "Wave"}, ...
    "prefix", {"ES",  "GS",  "WS"} ...
);

if ~isfolder(OUTPUT_DIR)
    mkdir(OUTPUT_DIR);
end

%% ---- Main loop over buoys ----------------------------------------------
for b = 1:numel(BUOYS)
    buoyName = BUOYS(b);
    buoyDir  = fullfile(ROOT_DIR, buoyName);
    rawDir   = fullfile(buoyDir, "raw");

    if ~isfolder(rawDir)
        warning("No raw/ folder found for %s at %s — skipping.", buoyName, rawDir);
        continue;
    end

    fprintf("Scanning %s ...\n", buoyName);
    manifest = table();

    for s = 1:numel(STREAMS)
        streamCode = STREAMS(s).code;
        streamDir  = fullfile(rawDir, streamCode);

        if ~isfolder(streamDir)
            warning("  Stream folder %s not found, skipping.", streamDir);
            continue;
        end

        sessionRows = scanStream(streamDir, STREAMS(s).label, STREAMS(s).prefix);
        manifest = [manifest; sessionRows]; %#ok<AGROW>
    end

    % Sort for readability: stream, then session number
    manifest = sortrows(manifest, {'Stream', 'SessionNum'});

    outCsv = fullfile(OUTPUT_DIR, buoyName + "_raw_inventory.csv");
    writetable(manifest, outCsv);
    fprintf("  Wrote %s (%d sessions)\n", outCsv, height(manifest));

    % Flag anything worth looking at before you build parsers
    flagIssues(manifest, buoyName);

    allManifests.(buoyName) = manifest; %#ok<STRNU>
end

if isempty(fieldnames(allManifests))
    warning("No buoys were successfully scanned — check ROOT_DIR and folder names before re-running.");
else
    save(fullfile(OUTPUT_DIR, "raw_inventory_all_buoys.mat"), "allManifests");
    fprintf("\nDone. Combined tables saved to raw_inventory_all_buoys.mat\n");
end


%% ======================================================================
function sessionRows = scanStream(streamDir, streamLabel, sessionPrefix)
% Scan one stream folder (e.g. raw/WD) and build one manifest row per
% session subfolder (e.g. WS1, WS2, ...).

    sessionDirs = dir(streamDir);
    sessionDirs = sessionDirs([sessionDirs.isdir] & ~startsWith({sessionDirs.name}, "."));

    n = numel(sessionDirs);
    Stream        = strings(n,1);
    Session       = strings(n,1);
    SessionNum    = nan(n,1);
    NumFiles      = zeros(n,1);
    TotalSizeKB   = zeros(n,1);
    FirstTime     = strings(n,1);
    LastTime      = strings(n,1);
    TimeWrapFlag  = false(n,1);
    ColCountVaries = false(n,1);
    HasAllCsv     = false(n,1);
    AllCsvRows    = nan(n,1);
    ReadErrors    = strings(n,1);

    for i = 1:n
        sessionName = sessionDirs(i).name;
        sessionPath = fullfile(streamDir, sessionName);

        Stream(i)  = streamLabel;
        Session(i) = sessionName;
        numMatch = regexp(sessionName, '\d+', 'match', 'once');
        if ~isempty(numMatch)
            SessionNum(i) = str2double(numMatch);
        end

        files = dir(fullfile(sessionPath, "*.txt"));
        NumFiles(i) = numel(files);
        TotalSizeKB(i) = sum([files.bytes]) / 1024;

        % Check for a pre-built "*All.csv"
        csvFiles = dir(fullfile(sessionPath, "*All.csv"));
        if ~isempty(csvFiles)
            HasAllCsv(i) = true;
            try
                allTbl = readtable(fullfile(sessionPath, csvFiles(1).name));
                AllCsvRows(i) = height(allTbl);
            catch ME
                ReadErrors(i) = "AllCsv read failed: " + string(ME.message);
            end
        end

        if NumFiles(i) == 0
            continue;
        end

        % Read first line of the first file and last line of the last
        % file (files are not guaranteed to be named in time order, so
        % this gives the range across the *files as listed*, not a
        % guaranteed chronological min/max — good enough to spot
        % anomalies, not a substitute for full parsing later).
        try
            firstLine = readFirstLine(fullfile(sessionPath, files(1).name));
            lastLine  = readLastLine(fullfile(sessionPath, files(end).name));

            [t1, ncols1] = parseLeadingTime(firstLine);
            [t2, ncols2] = parseLeadingTime(lastLine);

            FirstTime(i) = string(t1);
            LastTime(i)  = string(t2);
            ColCountVaries(i) = (ncols1 ~= ncols2);

            if ~isnan(t1) && ~isnan(t2) && t2 < t1
                % Later file's time-of-day is earlier than the first
                % file's — likely crossed midnight within this session.
                TimeWrapFlag(i) = true;
            end
        catch ME
            ReadErrors(i) = "Line parse failed: " + string(ME.message);
        end
    end

    sessionRows = table(Stream, Session, SessionNum, NumFiles, TotalSizeKB, ...
        FirstTime, LastTime, TimeWrapFlag, ColCountVaries, HasAllCsv, ...
        AllCsvRows, ReadErrors);
end

%% ------------------------------------------------------------------------
function line = readFirstLine(filepath)
    fid = fopen(filepath, 'r');
    if fid == -1
        error("Could not open %s", filepath);
    end
    line = fgetl(fid);
    fclose(fid);
    if ~ischar(line)
        line = '';
    end
end

%% ------------------------------------------------------------------------
function line = readLastLine(filepath)
    % Reads the whole file to get the last non-empty line. Fine for
    % files up to a few thousand lines (individual burst samples);
    % revisit with a seek-from-end approach if WD sample files turn out
    % to be very large.
    txt = fileread(filepath);
    lines = splitlines(string(txt));
    lines = lines(strlength(strtrim(lines)) > 0);
    if isempty(lines)
        line = '';
    else
        line = char(lines(end));
    end
end

%% ------------------------------------------------------------------------
function [timeOfDayHours, numCols] = parseLeadingTime(line)
    % Parses "H:MM:SS, val1, val2, ..." style lines, tolerant of
    % inconsistent zero-padding (e.g. "17:9:4" or "1:20:25").
    % Returns time-of-day as decimal hours (for easy min/max comparison)
    % and the number of comma-separated fields on the line.
    timeOfDayHours = NaN;
    numCols = NaN;

    if isempty(line)
        return;
    end

    parts = strsplit(strtrim(line), ',');
    numCols = numel(parts);

    hms = strsplit(strtrim(parts{1}), ':');
    if numel(hms) ~= 3
        return;
    end

    h = str2double(hms{1});
    m = str2double(hms{2});
    s = str2double(hms{3});
    if any(isnan([h m s]))
        return;
    end

    timeOfDayHours = h + m/60 + s/3600;
end

%% ------------------------------------------------------------------------
function flagIssues(manifest, buoyName)
    % Print a short heads-up list so anomalies aren't buried in a CSV.
    fprintf("  --- Flags for %s ---\n", buoyName);

    wrapped = manifest(manifest.TimeWrapFlag, :);
    if ~isempty(wrapped)
        fprintf("  %d session(s) appear to cross midnight (check before assuming a single date per session):\n", height(wrapped));
        disp(wrapped(:, {'Stream','Session'}));
    end

    varyingCols = manifest(manifest.ColCountVaries, :);
    if ~isempty(varyingCols)
        fprintf("  %d session(s) have inconsistent column counts between first/last file (mixed format?):\n", height(varyingCols));
        disp(varyingCols(:, {'Stream','Session'}));
    end

    noFiles = manifest(manifest.NumFiles == 0, :);
    if ~isempty(noFiles)
        fprintf("  %d session(s) contain zero .txt files:\n", height(noFiles));
        disp(noFiles(:, {'Stream','Session'}));
    end

    withErrors = manifest(manifest.ReadErrors ~= "", :);
    if ~isempty(withErrors)
        fprintf("  %d session(s) hit a read error — see ReadErrors column in the CSV.\n", height(withErrors));
    end

    if isempty(wrapped) && isempty(varyingCols) && isempty(noFiles) && isempty(withErrors)
        fprintf("  No anomalies flagged.\n");
    end
end