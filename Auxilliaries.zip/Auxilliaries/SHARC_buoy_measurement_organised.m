%% sharc_meas_real.m
%
% Adapted from sharc_meas.m to run the SAME onboard DSP chain (detrend,
% decimate, RC high-pass, windowed FFT, Bartlett AND Welch averaging,
% directional recovery, 2D spectrum reconstruction) on REAL SB04 data
% from all/SB04WaveTable.csv, instead of the synthetic eta(t) generated
% by ocean_wave_spectrum.m.
%
% The synthetic IMU sensor-model block from sharc_meas.m (gyro model,
% accelerometer noise, complementary filter fusion) is skipped entirely
% here -- that block exists to simulate what a real sensor would report;
% you already have what a real sensor reported.
%
% OPEN QUESTIONS -- confirm these before trusting any numbers this script
% prints or plots:
%   1. Is Heave already a physical displacement, or a raw accelerometer
%      count needing the acceleration->displacement inversion the
%      original DSP chain applies? -> HEAVE_IS_DISPLACEMENT below.
%   2. Column order: this file follows SB04WaveTable.csv's own header
%      (..., Roll, Pitch, ...). WS*All.csv uses the OPPOSITE order
%      (..., Pitch, Roll, ...) -- confirm which is correct before
%      trusting the Sx/Sy assignment below.
%   3. No scale factor is applied to the raw columns here -- SCALE_HEAVE
%      and SCALE_ANGLE_DEG default to 1 ("unconverted") until you have a
%      confirmed calibration. Raw Heave values (~8000-8200 counts) and
%      Roll/Pitch (0-100+ counts) strongly suggest these are NOT already
%      metres/degrees -- do not trust Hm0/direction numbers until this
%      is resolved.
%   4. SIGN CONVENTION on Qzx/Qzy: directional_validation.m found the
%      synthetic pipeline needed Qzx/Qzy negated to match the input
%      truth direction. That fix followed directly from how
%      ocean_wave_spectrum.m defines Sx/Sy's phase relative to eta(t)
%      (a *known* convention for synthetic data). For REAL IMU data we
%      do NOT know that phase relationship a priori -- it depends on the
%      sensor's own sign/axis conventions. DO NOT blindly copy the
%      negation here. SIGN_QUAD below defaults to +1 (unflipped); flip
%      it to -1 only once you've validated recovered direction against
%      an independent truth (e.g. the buoy's own reported mean direction
%      in the summary CSV, or a known swell direction for that day).

clear; clc;

%% ---- Configuration ----
WAVETABLE_CSV          = "SB04WaveTable.csv";  % <-- EDIT
HEAVE_IS_DISPLACEMENT  = true;   % <-- EDIT once confirmed, see note above
SCALE_HEAVE            = 1;      % raw-count -> metres, once known
SCALE_ANGLE_DEG        = 1;      % raw-count -> degrees, once known (1 = "already degrees")
SIGN_QUAD              = 1;      % +1 or -1, see note 4 above -- do not assume

%% ---- Load and inspect the raw table ----
T = readtable(WAVETABLE_CSV);
T.DateTimeUTC = datetime(T.DateTimeUTC, 'InputFormat', 'dd-MMM-yyyy HH:mm:ss');

fprintf("Loaded %d rows, %s to %s\n", height(T), T.DateTimeUTC(1), T.DateTimeUTC(end));
fprintf("Unique timeSeriesCount values: %s\n", mat2str(unique(T.timeSeriesCount)'));
fprintf("sampleCount range: %d to %d\n", min(T.sampleCount), max(T.sampleCount));

%% ---- Estimate the real sample rate ----
% DateTimeUTC only has 1-second resolution, so this counts how many rows
% fall inside each distinct second -- an ESTIMATE, not a confirmed spec
% value. Cross-check against your supervisor's answer if possible.
[~, ~, secIdx] = unique(T.DateTimeUTC);
rowsPerSecond = accumarray(secIdx, 1);
fs_imu = median(rowsPerSecond);
fprintf("Estimated sample rate: %.1f Hz (median rows per distinct second)\n", fs_imu);

n = height(T);
t_imu = (0:n-1) / fs_imu;

%% ---- Raw channel plots (visualise before touching units) ----
figure('Name', 'SB04WaveTable raw channels');
subplot(3,2,1); plot(t_imu, T.Surge); title('Surge (raw)'); grid on;
subplot(3,2,2); plot(t_imu, T.Sway);  title('Sway (raw)');  grid on;
subplot(3,2,3); plot(t_imu, T.Heave); title('Heave (raw)'); grid on;
subplot(3,2,4); plot(t_imu, T.Roll);  title('Roll (raw)');  grid on;
subplot(3,2,5); plot(t_imu, T.Pitch); title('Pitch (raw)'); grid on;
subplot(3,2,6); plot(t_imu, T.Yaw);   title('Yaw (raw)');   grid on;
sgtitle('all/SB04WaveTable.csv -- raw channels');

%% ---- Build heave / slope inputs for the existing DSP chain ----
% Convention assumed: pitch -> Sx (north-south slope), roll -> Sy
% (east-west slope). VERIFY this axis convention and the units (degrees
% vs raw counts) against the manufacturer docs / supervisor before
% trusting direction output.
Sx_fused = deg2rad(SCALE_ANGLE_DEG * T.Pitch);
Sy_fused = deg2rad(SCALE_ANGLE_DEG * T.Roll);

if HEAVE_IS_DISPLACEMENT
    heave_disp = SCALE_HEAVE * T.Heave;
else
    heave_accel = SCALE_HEAVE * T.Heave; %#ok<UNRCH>
end

%% ---- Existing DSP pipeline (copied from sharc_meas.m) ----
M = 32;
fs_dec = fs_imu / M;
cutoff_norm = min(0.9, 1.12 / (fs_imu/2));
lpf = fir1(64, cutoff_norm);
tau = 100;
k_rc = exp(-1/(tau*fs_dec));
f_min = 0.03;

if HEAVE_IS_DISPLACEMENT
    heave_dec = downsample(filtfilt(lpf, 1, detrend(heave_disp)), M);
else
    heave_dec = downsample(filtfilt(lpf, 1, detrend(heave_accel)), M); %#ok<UNRCH>
end
heave_hp = zeros(size(heave_dec));
for i = 2:length(heave_dec)
    heave_hp(i) = k_rc*heave_hp(i-1) + k_rc*(heave_dec(i) - heave_dec(i-1));
end

Sx_dec = downsample(filtfilt(lpf, 1, Sx_fused), M);
Sy_dec = downsample(filtfilt(lpf, 1, Sy_fused), M);
Sx_hp = zeros(size(Sx_dec)); Sy_hp = zeros(size(Sy_dec));
for i = 2:length(Sx_dec)
    Sx_hp(i) = k_rc*Sx_hp(i-1) + k_rc*(Sx_dec(i) - Sx_dec(i-1));
    Sy_hp(i) = k_rc*Sy_hp(i-1) + k_rc*(Sy_dec(i) - Sy_dec(i-1));
end

Nsamples = length(heave_hp);
Nfft = 1024;
Nseg = floor(Nsamples / Nfft);
if Nseg < 1
    error("Only %d decimated samples -- not enough for one %d-sample FFT segment.", ...
        Nsamples, Nfft);
elseif Nseg < 6
    warning("Only %d full %d-sample segment(s) available; the thesis Bartlett average uses N=6.", ...
        Nseg, Nfft);
end

win = hanning(Nfft);
freq_axis = (0:Nfft/2-1) * (fs_dec/Nfft);
valid = freq_axis >= f_min & freq_axis <= 0.5;

%% ---- Bartlett segmentation ----
seg_Z = zeros(Nfft/2, Nseg); seg_X = zeros(Nfft/2, Nseg); seg_Y = zeros(Nfft/2, Nseg);
for s = 1:Nseg
    idx = (s-1)*Nfft + (1:Nfft);

    xz = heave_hp(idx) .* win(:)';
    Xz = fft(xz, Nfft); Xz = Xz(1:Nfft/2);
    if ~HEAVE_IS_DISPLACEMENT
        Xz_disp = zeros(1, Nfft/2); %#ok<UNRCH>
        Xz_disp(valid) = Xz(valid) .* (-1 ./ (2*pi*freq_axis(valid)).^2);
    else
        Xz_disp = Xz;
        Xz_disp(~valid) = 0;
    end
    seg_Z(:,s) = Xz_disp;

    xx = Sx_hp(idx) .* win(:)'; Xx = fft(xx, Nfft); Xx = Xx(1:Nfft/2); Xx(~valid) = 0;
    seg_X(:,s) = Xx;

    xy = Sy_hp(idx) .* win(:)'; Xy = fft(xy, Nfft); Xy = Xy(1:Nfft/2); Xy(~valid) = 0;
    seg_Y(:,s) = Xy;
end

%% ---- Welch segmentation (50% overlap, parallel to Bartlett) ----
overlap_frac = 0.5;
hop = round(Nfft * (1 - overlap_frac));
Nseg_w = floor((Nsamples - Nfft) / hop) + 1;

seg_Z_w = zeros(Nfft/2, Nseg_w); seg_X_w = zeros(Nfft/2, Nseg_w); seg_Y_w = zeros(Nfft/2, Nseg_w);
for s = 1:Nseg_w
    idx = (s-1)*hop + (1:Nfft);

    xz = heave_hp(idx) .* win(:)';
    Xz = fft(xz, Nfft); Xz = Xz(1:Nfft/2);
    if ~HEAVE_IS_DISPLACEMENT
        Xz_disp = zeros(1, Nfft/2); %#ok<UNRCH>
        Xz_disp(valid) = Xz(valid) .* (-1 ./ (2*pi*freq_axis(valid)).^2);
    else
        Xz_disp = Xz;
        Xz_disp(~valid) = 0;
    end
    seg_Z_w(:,s) = Xz_disp;

    xx = Sx_hp(idx) .* win(:)'; Xx = fft(xx, Nfft); Xx = Xx(1:Nfft/2); Xx(~valid) = 0;
    seg_X_w(:,s) = Xx;

    xy = Sy_hp(idx) .* win(:)'; Xy = fft(xy, Nfft); Xy = Xy(1:Nfft/2); Xy(~valid) = 0;
    seg_Y_w(:,s) = Xy;
end

%% ---- Bartlett auto-spectra + moments ----
K_norm = 2 / (fs_dec * sum(win.^2));
Czz_avg = K_norm * mean(abs(seg_Z).^2, 2);
Cxx_avg = K_norm * mean(abs(seg_X).^2, 2);
Cyy_avg = K_norm * mean(abs(seg_Y).^2, 2);

m0 = trapz(freq_axis, Czz_avg);
m1 = trapz(freq_axis, freq_axis(:) .* Czz_avg(:));
Hm0_sharc = 4*sqrt(m0);
Tm01_sharc = m0 / m1;
fprintf('\nSHARC-measured (real data, Bartlett): Hm0 = %.3f m, Tm01 = %.2f s\n', Hm0_sharc, Tm01_sharc);
fprintf('Compare against the matching row(s) in the top-level summary CSV.\n');

%% ---- Welch auto-spectra + moments ----
Czz_avg_w = K_norm * mean(abs(seg_Z_w).^2, 2);
Cxx_avg_w = K_norm * mean(abs(seg_X_w).^2, 2);
Cyy_avg_w = K_norm * mean(abs(seg_Y_w).^2, 2);

m0_w = trapz(freq_axis, Czz_avg_w);
m1_w = trapz(freq_axis, freq_axis(:) .* Czz_avg_w(:));
Hm0_sharc_w = 4*sqrt(m0_w);
Tm01_sharc_w = m0_w / m1_w;
fprintf('SHARC-measured (real data, Welch)   : Hm0 = %.3f m, Tm01 = %.2f s\n', Hm0_sharc_w, Tm01_sharc_w);

%% ---- Direction recovery: Bartlett ----
Qzx_avg = SIGN_QUAD * K_norm * mean(imag(seg_Z .* conj(seg_X)), 2);
Qzy_avg = SIGN_QUAD * K_norm * mean(imag(seg_Z .* conj(seg_Y)), 2);
Cxy_avg = K_norm * mean(real(seg_X .* conj(seg_Y)), 2);

a1 = Qzx_avg ./ sqrt(Czz_avg .* (Cxx_avg + Cyy_avg));
b1 = Qzy_avg ./ sqrt(Czz_avg .* (Cxx_avg + Cyy_avg));
a2 = (Cxx_avg - Cyy_avg) ./ (Cxx_avg + Cyy_avg);
b2 = 2*Cxy_avg ./ (Cxx_avg + Cyy_avg);

theta1_deg = mod(90 - rad2deg(atan2(b1, a1)), 360);   % math -> compass bearing
spread_deg = rad2deg(sqrt(max(2*(1 - sqrt(a1.^2 + b1.^2)), 0)));

%% ---- Direction recovery: Welch ----
Qzx_avg_w = SIGN_QUAD * K_norm * mean(imag(seg_Z_w .* conj(seg_X_w)), 2);
Qzy_avg_w = SIGN_QUAD * K_norm * mean(imag(seg_Z_w .* conj(seg_Y_w)), 2);
Cxy_avg_w = K_norm * mean(real(seg_X_w .* conj(seg_Y_w)), 2);

a1_w = Qzx_avg_w ./ sqrt(Czz_avg_w .* (Cxx_avg_w + Cyy_avg_w));
b1_w = Qzy_avg_w ./ sqrt(Czz_avg_w .* (Cxx_avg_w + Cyy_avg_w));
a2_w = (Cxx_avg_w - Cyy_avg_w) ./ (Cxx_avg_w + Cyy_avg_w);
b2_w = 2*Cxy_avg_w ./ (Cxx_avg_w + Cyy_avg_w);

theta1_deg_w = mod(90 - rad2deg(atan2(b1_w, a1_w)), 360);
spread_deg_w = rad2deg(sqrt(max(2*(1 - sqrt(a1_w.^2 + b1_w.^2)), 0)));

band = freq_axis >= f_min & freq_axis <= 0.3;

%% ---- Plot: direction & spread vs frequency, Bartlett vs Welch ----
figure('Name', 'Direction recovery -- real data');
subplot(2,1,1);
plot(freq_axis(band), theta1_deg(band), 'o-', 'LineWidth', 1.0); hold on;
plot(freq_axis(band), theta1_deg_w(band), 'x--', 'LineWidth', 1.0);
ylabel('\theta_1(f) (deg, compass bearing)');
legend('Bartlett', 'Welch'); grid on;
title('SHARC-recovered direction vs frequency (real data)');
subplot(2,1,2);
plot(freq_axis(band), spread_deg(band), 'o-', 'LineWidth', 1.0); hold on;
plot(freq_axis(band), spread_deg_w(band), 'x--', 'LineWidth', 1.0);
xlabel('Frequency (Hz)'); ylabel('Spread (deg)');
legend('Bartlett', 'Welch'); grid on;

%% ---- Reconstruct E(f,theta) from Fourier coefficients ----
build_E2D_compass = @(Czz,a1,b1,a2,b2,theta_c_rad) ...
    Czz .* max( (1/pi)*(0.5 + a1.*sin(theta_c_rad) + b1.*cos(theta_c_rad) ...
                 - a2.*cos(2*theta_c_rad) + b2.*sin(2*theta_c_rad)), 0 );

theta_grid = (0:2:358)';              % compass bearing, deg
theta_c_rad = deg2rad(theta_grid)';   % row vector

E2D_bart  = build_E2D_compass(Czz_avg,   a1,   b1,   a2,   b2,   theta_c_rad);
E2D_welch = build_E2D_compass(Czz_avg_w, a1_w, b1_w, a2_w, b2_w, theta_c_rad);

f_band = freq_axis(band);
E2D_bart_norm  = E2D_bart(band,:)  / max(E2D_bart(band,:), [], 'all');
E2D_welch_norm = E2D_welch(band,:) / max(E2D_welch(band,:), [], 'all');

%% ---- Plot: Bartlett vs Welch directional spectra -- compass-bearing heatmaps ----
fmax = 0.3;
[Theta, F] = meshgrid(theta_grid, f_band);
Xc = F .* sind(Theta);
Yc = F .* cosd(Theta);

figure('Name', 'Directional spectrum (Bartlett) -- real data', 'Position',[100 100 600 600]);
pcolor(Xc, Yc, E2D_bart_norm); shading interp; colormap(jet); axis equal; hold on;
add_polar_grid(fmax);
xlim([-fmax fmax]*1.2); ylim([-fmax fmax]*1.2);
title('Bartlett-averaged directional spectrum (real data)'); colorbar; caxis([0 1]);

figure('Name', 'Directional spectrum (Welch) -- real data', 'Position',[100 100 600 600]);
pcolor(Xc, Yc, E2D_welch_norm); shading interp; colormap(jet); axis equal; hold on;
add_polar_grid(fmax);
xlim([-fmax fmax]*1.2); ylim([-fmax fmax]*1.2);
title('Welch-averaged directional spectrum (real data)'); colorbar; caxis([0 1]);

%% ---- Plot: Bartlett vs Welch auto-spectra ----
figure('Name', 'Auto-spectra -- real data');
plot(freq_axis, Czz_avg, 'LineWidth', 1.2); hold on;
plot(freq_axis, Cxx_avg, 'LineWidth', 1.2);
plot(freq_axis, Cyy_avg, 'LineWidth', 1.2);
xlim([0 0.3]);
xlabel('Frequency (Hz)'); ylabel('PSD');
legend('C_{zz} (heave)', 'C_{xx} (S_x)', 'C_{yy} (S_y)');
title('Bartlett-averaged auto-spectra -- real SB04 data'); grid on;

figure('Name', 'Heave PSD: Bartlett vs Welch -- real data');
plot(freq_axis, Czz_avg, 'LineWidth', 1.2); hold on;
plot(freq_axis, Czz_avg_w, '--', 'LineWidth', 1.2);
xlim([0 0.3]); xlabel('Frequency (Hz)'); ylabel('C_{zz} PSD');
legend('Bartlett', 'Welch'); title('Heave (C_{zz}): Bartlett vs Welch'); grid on;

%% ---- Local functions (must be at end of script) ----
function add_polar_grid(rmax)
    rings = 0:0.05:rmax;
    th = linspace(0,2*pi,200);
    for r = rings
        plot(r*cos(th), r*sin(th), 'Color',[0.7 0.7 0.7],'LineStyle',':');
    end
    for ang = 0:45:315
        plot([0 rmax*sind(ang)], [0 rmax*cosd(ang)], 'Color',[0.7 0.7 0.7],'LineStyle',':');
    end
    text(0,rmax*1.05,'North','HorizontalAlignment','center');
    text(rmax*1.08,0,'East','HorizontalAlignment','left');
    text(0,-rmax*1.1,'South','HorizontalAlignment','center');
    text(-rmax*1.08,0,'West','HorizontalAlignment','right');
end