%% =========================================================
% ERA5 SEA ICE CONCENTRATION
% South African Antarctic Sector
%
% Data period:
% 11 July 2022 - 31 July 2022
%
% Plots:
% 11 July 2022
% 30 July 2022
%
% Longitude:
% 20 W to 40 E
% ==========================================================

clear;
clc;
close all;

%% ---------------------------------------------------------
% 1. File
% ---------------------------------------------------------

filename = 'Era5Ice.nc';

%% ---------------------------------------------------------
% 2. Read data
% ---------------------------------------------------------

longitude = ncread(filename,'longitude');
latitude  = ncread(filename,'latitude');
time      = ncread(filename,'valid_time');

siconc = ncread(filename,'siconc');

%% ---------------------------------------------------------
% 3. Convert UNIX time to MATLAB datetime
% ---------------------------------------------------------

timeDate = datetime(1970,1,1) + seconds(time);

fprintf('\n============================================\n');
fprintf('ERA5 TIME RANGE\n');
fprintf('============================================\n');

fprintf('Start: %s\n',string(timeDate(1)));
fprintf('End:   %s\n',string(timeDate(end)));

%% ---------------------------------------------------------
% 4. Define South African Antarctic sector
% ---------------------------------------------------------

% 20 degrees West
lonMin = -20;

% 40 degrees East
lonMax = 40;

% SANAE IV:
% 2 degrees 49 minutes West

sanaeLon = -(2 + 49/60);

%% ---------------------------------------------------------
% 5. Select longitude range
% ---------------------------------------------------------

lonIndex = longitude >= lonMin & longitude <= lonMax;

lonRegion = longitude(lonIndex);

%% ---------------------------------------------------------
% 6. Requested dates
% ---------------------------------------------------------

date1 = datetime(2022,7,11);
date2 = datetime(2022,7,30);

%% ---------------------------------------------------------
% 7. Find closest ERA5 time
% ---------------------------------------------------------

[~,index1] = min(abs(timeDate - date1));
[~,index2] = min(abs(timeDate - date2));

actualDate1 = timeDate(index1);
actualDate2 = timeDate(index2);

fprintf('\n============================================\n');
fprintf('REQUESTED DATES\n');
fprintf('============================================\n');

fprintf('Requested: 11 July 2022\n');
fprintf('ERA5 time: %s\n',string(actualDate1));

fprintf('\nRequested: 30 July 2022\n');
fprintf('ERA5 time: %s\n',string(actualDate2));

%% ---------------------------------------------------------
% 8. Extract the two spatial fields
% ---------------------------------------------------------

ice1 = siconc(lonIndex,:,index1);
ice2 = siconc(lonIndex,:,index2);

% Convert fraction to percentage

ice1 = 100 * ice1;
ice2 = 100 * ice2;

%% ---------------------------------------------------------
% 9. Check dimensions
% ---------------------------------------------------------

fprintf('\n============================================\n');
fprintf('DATA DIMENSIONS\n');
fprintf('============================================\n');

fprintf('Longitude: %d points\n',length(lonRegion));
fprintf('Latitude:  %d points\n',length(latitude));

fprintf('11 July field: ');
disp(size(ice1));

fprintf('30 July field: ');
disp(size(ice2));

%% =========================================================
% 10. SIDE-BY-SIDE SPATIAL PLOT
% ==========================================================

figure('Color','w','Position',[100 100 1300 550]);

tiledlayout(1,2,'TileSpacing','compact','Padding','compact');

%% ---------------------------------------------------------
% 11 July
% ---------------------------------------------------------

nexttile;

imagesc(lonRegion,latitude,ice1');

set(gca,'YDir','normal');

hold on;

% SANAE IV longitude
xline(sanaeLon,'k--','LineWidth',2);

xlabel('Longitude (°E)');
ylabel('Latitude (°S)');

title(sprintf( ...
    '11 July 2022\nERA5: %s', ...
    datestr(actualDate1,'dd-mmm-yyyy HH:MM')));

clim([0 100]);

xlim([lonMin lonMax]);

ylim([min(latitude) max(latitude)]);

grid on;

% SANAE label
text(sanaeLon + 0.7, ...
     max(latitude)-1, ...
     'SANAE IV', ...
     'FontWeight','bold');

%% ---------------------------------------------------------
% 30 July
% ---------------------------------------------------------

nexttile;

imagesc(lonRegion,latitude,ice2');

set(gca,'YDir','normal');

hold on;

% SANAE IV longitude
xline(sanaeLon,'k--','LineWidth',2);

xlabel('Longitude (°E)');
ylabel('Latitude (°S)');

title(sprintf( ...
    '30 July 2022\nERA5: %s', ...
    datestr(actualDate2,'dd-mmm-yyyy HH:MM')));

clim([0 100]);

xlim([lonMin lonMax]);

ylim([min(latitude) max(latitude)]);

grid on;

% SANAE label
text(sanaeLon + 0.7, ...
     max(latitude)-1, ...
     'SANAE IV', ...
     'FontWeight','bold');

%% ---------------------------------------------------------
% Shared colourbar
% ---------------------------------------------------------

cb = colorbar;
cb.Layout.Tile = 'east';

cb.Label.String = 'Sea Ice Concentration (%)';

sgtitle('ERA5 Sea Ice Concentration — South African Antarctic Sector');
