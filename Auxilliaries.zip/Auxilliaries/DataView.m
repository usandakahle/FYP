%% ERA5 Wave Data Visualisation
clear;
clc;
close all;

filename = 'Era5.nc';

%% ---------------------------------------------------------
% 1. Display NetCDF structure
% ----------------------------------------------------------

ncdisp(filename);

%% ---------------------------------------------------------
% 2. Get file information
% ----------------------------------------------------------

info = ncinfo(filename);

fprintf('\n========================================\n');
fprintf('ERA5 NETCDF VARIABLES\n');
fprintf('========================================\n');

for k = 1:length(info.Variables)

    v = info.Variables(k);

    fprintf('\nVariable: %s\n', v.Name);

    fprintf('Dimensions: ');
    for j = 1:length(v.Dimensions)
        fprintf('%s ', v.Dimensions(j).Name);
    end
    fprintf('\n');

    try
        fprintf('Units: %s\n', ...
            ncreadatt(filename,v.Name,'units'));
    catch
        fprintf('Units: not specified\n');
    end

end

%% ---------------------------------------------------------
% 3. Read coordinates
% ----------------------------------------------------------

latitude  = ncread(filename,'latitude');
longitude = ncread(filename,'longitude');
time      = ncread(filename,'valid_time');

%% ---------------------------------------------------------
% 4. Display coordinate information
% ----------------------------------------------------------

fprintf('\nLatitude range: %.2f to %.2f\n', ...
    min(latitude), max(latitude));

fprintf('Longitude range: %.2f to %.2f\n', ...
    min(longitude), max(longitude));

fprintf('Number of time steps: %d\n',length(time));

%% ---------------------------------------------------------
% 5. Read time units
% ----------------------------------------------------------

timeUnits = ncreadatt(filename,'valid_time','units');

fprintf('\nTime units: %s\n',timeUnits);

%% ---------------------------------------------------------
% 6. Convert time
% ----------------------------------------------------------

% This assumes the common ERA5 convention.
% Check the printed time units above before relying on this.

timeDate = datetime(1900,1,1) + hours(time);

%% ---------------------------------------------------------
% 7. Select wave variable
% ----------------------------------------------------------

% CHANGE THIS NAME after looking at ncdisp()
waveVariable = 'swh';

waveData = ncread(filename,waveVariable);

%% ---------------------------------------------------------
% 8. Basic statistics
% ----------------------------------------------------------

fprintf('\n========================================\n');
fprintf('WAVE DATA STATISTICS\n');
fprintf('========================================\n');

fprintf('Minimum: %.3f\n',min(waveData(:),[],'omitnan'));
fprintf('Maximum: %.3f\n',max(waveData(:),[],'omitnan'));
fprintf('Mean:    %.3f\n',mean(waveData(:),'omitnan'));

fprintf('Data size:\n');
disp(size(waveData));

%% ---------------------------------------------------------
% 15. ERA5 Data Summary
% ----------------------------------------------------------

fprintf('\n========================================\n');
fprintf('ERA5 DATA SUMMARY\n');
fprintf('========================================\n');

% Data period
fprintf('\nData period:\n');
fprintf('  From: %s\n',datestr(timeDate(1),'dd-mmm-yyyy HH:MM'));
fprintf('  To:   %s\n',datestr(timeDate(end),'dd-mmm-yyyy HH:MM'));

% Geographic coverage
fprintf('\nGeographical coverage:\n');
fprintf('  Latitude:  %.2f° to %.2f°\n', ...
    min(latitude),max(latitude));

fprintf('  Longitude: %.2f° to %.2f°\n', ...
    min(longitude),max(longitude));

% Full variable name
switch lower(waveVariable)

    case 'swh'
        dataFullName = 'Significant Wave Height';

    case 'pp1d'
        dataFullName = 'Peak Wave Period';

    case 'mwp'
        dataFullName = 'Mean Wave Period';

    case 'mwd'
        dataFullName = 'Mean Wave Direction';

    case 'siconc'
        dataFullName = 'Sea Ice Concentration';

    otherwise
        try
            dataFullName = ncreadatt(filename,waveVariable,'long_name');
        catch
            dataFullName = waveVariable;
        end
end

fprintf('\nData variable:\n');
fprintf('  %s\n',dataFullName);

fprintf('  NetCDF variable name: %s\n',waveVariable);

fprintf('\n========================================\n');

%% ---------------------------------------------------------
% 9. Plot first time step
% ----------------------------------------------------------

figure;

imagesc(longitude,latitude,waveData(:,:,1)');

set(gca,'YDir','normal');

xlabel('Longitude');
ylabel('Latitude');

title(sprintf('ERA5 %s - First Time Step',waveVariable), ...
    'Interpreter','none');

colorbar;

%% ---------------------------------------------------------
% 10. Plot time series of spatial mean
% ----------------------------------------------------------

% Average over longitude and latitude
meanWave = squeeze( ...
    mean(mean(waveData,1,'omitnan'),2,'omitnan'));

figure;

plot(timeDate,meanWave,'LineWidth',1.2);

xlabel('Date');
ylabel(waveVariable,'Interpreter','none');

title('Spatially Averaged ERA5 Wave Data');

grid on;

%% ---------------------------------------------------------
% 11. Interactive location selection
% ----------------------------------------------------------

figure;

imagesc(longitude,latitude,waveData(:,:,1)');

set(gca,'YDir','normal');

xlabel('Longitude');
ylabel('Latitude');

title('Select a Location');

colorbar;

[x,y] = ginput(1);

fprintf('\nSelected location:\n');
fprintf('Longitude: %.3f\n',x);
fprintf('Latitude:  %.3f\n',y);

%% ---------------------------------------------------------
% 12. Find nearest ERA5 grid point
% ----------------------------------------------------------

[~,lonIndex] = min(abs(longitude-x));
[~,latIndex] = min(abs(latitude-y));

fprintf('\nNearest ERA5 grid point:\n');
fprintf('Longitude: %.3f\n',longitude(lonIndex));
fprintf('Latitude:  %.3f\n',latitude(latIndex));

%% ---------------------------------------------------------
% 13. Extract local wave time series
% ----------------------------------------------------------

localWave = squeeze( ...
    waveData(lonIndex,latIndex,:));

%% ---------------------------------------------------------
% 14. Plot local wave time series
% ----------------------------------------------------------

figure;

plot(timeDate,localWave,'LineWidth',1.2);

xlabel('Date');
ylabel(waveVariable,'Interpreter','none');

title(sprintf( ...
    'ERA5 Wave Conditions at %.2f°N, %.2f°E', ...
    latitude(latIndex),longitude(lonIndex)));

grid on;