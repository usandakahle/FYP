%% extract_reference_directions.m
% Reads every reference figure wb_DD_HH.png, OCRs the "Pdir(..) = ..., Mdir(..) = ..."
% text above the map panel, and writes one row per figure to Excel.
%   wb_23_19 -> 23 July, 19:00 UTC
% Needs the Computer Vision Toolbox (ocr).

clc;

%% CONFIG
REF_DIR  = "LP8_dir/Figures";
YEAR     = 2022;
MONTH    = 7;
OUT_XLSX = "reference_directions.xlsx";
CHECK_DIR = "ocr_check";             % crops of failed reads are saved here
% Text region as fractions of image size [x y w h], calibrated on wb_22_01.png (1447x1171).
% If your figures were exported at another layout, adjust and check a crop in CHECK_DIR.
CROP = [0.00 0.475 0.33 0.07];
UPSCALE = 3;

%% FILES
files = dir(fullfile(REF_DIR, "wb_*.*"));
files = files(~[files.isdir]);
[~, ~, ext] = cellfun(@fileparts, {files.name}, 'UniformOutput', false);
files = files(ismember(lower(ext), {'.png','.jpg','.jpeg','.tif','.tiff','.bmp'}));
if isempty(files), error('No wb_*.png files in %s.', REF_DIR); end
fprintf('Found %d reference figures.\n', numel(files));

n = numel(files);
TimeUTC = NaT(n,1,'TimeZone','UTC');
File = strings(n,1); Ref_buoy = strings(n,1); OCR_text = strings(n,1);
Pdir_1 = nan(n,1); Pdir_2 = nan(n,1); Mdir_1 = nan(n,1); Mdir_2 = nan(n,1);
OK = false(n,1);

for k = 1:n
    File(k) = files(k).name;
    tok = regexp(files(k).name, '^wb_(\d{1,2})_(\d{1,2})', 'tokens', 'once');
    if isempty(tok)
        warning('%s: name does not match wb_DD_HH, skipped.', files(k).name);
        continue;
    end
    TimeUTC(k) = datetime(YEAR, MONTH, str2double(tok{1}), str2double(tok{2}), 0, 0, 'TimeZone','UTC');

    I = imread(fullfile(files(k).folder, files(k).name));
    if size(I,3) == 3, I = rgb2gray(I); end
    [H, W] = size(I);
    r = max(1, round(CROP(2)*H)) : min(H, round((CROP(2)+CROP(4))*H));
    c = max(1, round(CROP(1)*W)) : min(W, round((CROP(1)+CROP(3))*W));
    Ic = imresize(I(r, c), UPSCALE);

    txt = run_ocr(Ic);
    OCR_text(k) = strjoin(strtrim(splitlines(string(txt))), ' | ');

    [p, buoy] = parse_dir(txt, 'Pdir');
    [m, ~]    = parse_dir(txt, 'Mdir');
    Ref_buoy(k) = buoy;
    if numel(p) >= 1, Pdir_1(k) = p(1); end
    if numel(p) >= 2, Pdir_2(k) = p(2); end
    if numel(m) >= 1, Mdir_1(k) = m(1); end
    if numel(m) >= 2, Mdir_2(k) = m(2); end
    OK(k) = ~isnan(Mdir_1(k));

    if ~OK(k)
        if ~isfolder(CHECK_DIR), mkdir(CHECK_DIR); end
        imwrite(Ic, fullfile(CHECK_DIR, "crop_" + files(k).name));
        warning('%s: Mdir not read (OCR: "%s"). Crop saved to %s.', files(k).name, OCR_text(k), CHECK_DIR);
    end
end

T = table(TimeUTC, File, Ref_buoy, Pdir_1, Pdir_2, Mdir_1, Mdir_2, OK, OCR_text);
T = sortrows(T(~isnat(T.TimeUTC), :), 'TimeUTC');
T.TimeUTC.Format = 'yyyy-MM-dd HH:mm';

% Excel has no time zones: write the UTC time as plain datetime
Tx = T;  Tx.TimeUTC.TimeZone = '';
writetable(Tx, OUT_XLSX, 'Sheet', 'reference');
fprintf('Wrote %s: %d figures, %d with Mdir read.\n', OUT_XLSX, height(T), nnz(T.OK));
disp(T(:, {'TimeUTC','Ref_buoy','Pdir_1','Pdir_2','Mdir_1','Mdir_2','OK'}));

%% ---------------- local functions ----------------
function txt = run_ocr(I)
    try
        res = ocr(I, 'LayoutAnalysis', 'block');     % R2023a+
    catch
        res = ocr(I, 'TextLayout', 'Block');         % older releases
    end
    txt = res.Text;
end

function [vals, buoy] = parse_dir(txt, key)
% Line starting with key, e.g. "Mdir(LP8) = 112.0°, 112.0°,". Numbers are read
% only after "=", so the 8 in "LP8" is never picked up.
    vals = []; buoy = "";
    lines = splitlines(string(txt));
    L = lines(contains(lines, key, 'IgnoreCase', true));
    if isempty(L), return; end
    L = L(1);
    b = regexp(L, '\(([^)]+)\)', 'tokens', 'once');
    if ~isempty(b), buoy = string(b{1}); end
    rhs = extractAfter(L, "=");
    if ismissing(rhs), return; end
    num = regexp(rhs, '\d{1,3}(?:\.\d+)?', 'match');
    vals = str2double(num);
    vals = vals(vals >= 0 & vals <= 360);
end
